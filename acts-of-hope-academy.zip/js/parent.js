// Parent login and results rendering
async function sha256(text){
  if (window.crypto && window.crypto.subtle){
    const enc = new TextEncoder().encode(text);
    const hash = await window.crypto.subtle.digest('SHA-256', enc);
    return Array.from(new Uint8Array(hash)).map(b=>b.toString(16).padStart(2,'0')).join('');
  } else {
    throw new Error('This browser lacks Web Crypto support.');
  }
}

function byId(id){ return document.getElementById(id); }

async function fetchJSON(path){
  const res = await fetch(path, {cache: 'no-store'});
  if(!res.ok) throw new Error('Failed to load '+path);
  return await res.json();
}

function unique(values){
  return [...new Set(values)];
}

function renderTable(rows){
  const tbody = document.querySelector('#resultsTable tbody');
  tbody.innerHTML = '';
  rows.sort((a,b)=> (a.date > b.date ? -1 : 1));
  rows.forEach(r=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${r.date}</td><td>${r.year}</td><td>${r.term}</td><td>${r.subject}</td><td>${r.score}</td><td>${r.grade}</td><td>${r.remarks||''}</td>`;
    tbody.appendChild(tr);
  });
}

function computeSummary(rows){
  if(rows.length===0) return 'No results yet.';
  const avg = (rows.reduce((s,r)=>s+Number(r.score||0),0)/rows.length).toFixed(1);
  return `Subjects: ${rows.length} • Average: ${avg}`;
}

async function handleLogin(e){
  e.preventDefault();
  const id = byId('studentId').value.trim();
  const pin = byId('pin').value.trim();
  const err = byId('loginError');
  err.style.display = 'none';
  try{
    const [students, results] = await Promise.all([
      fetchJSON('data/students.json'),
      fetchJSON('data/results.json')
    ]);
    const student = students.find(s => s.studentId === id);
    if(!student){ throw new Error('Student ID not found.'); }
    const pinHash = await sha256(pin);
    if(student.pinHash !== pinHash){ throw new Error('Incorrect PIN.'); }

    // Fill meta
    byId('studentName').textContent = `${student.name} — ${student.studentId}`;
    byId('studentMeta').textContent = `${student.class} • Parent: ${student.parentName} (${student.parentPhone})`;

    // Filter and render
    let childRows = results.filter(r => r.studentId === id);

    // Populate filters
    const terms = unique(childRows.map(r=>r.term)).sort();
    const years = unique(childRows.map(r=>r.year)).sort();
    const termSel = byId('termFilter'), yearSel = byId('yearFilter');
    termSel.innerHTML = '<option value="">All</option>' + terms.map(t=>`<option value="${t}">${t}</option>`).join('');
    yearSel.innerHTML = '<option value="">All</option>' + years.map(y=>`<option value="${y}">${y}</option>`).join('');

    function applyFilters(){
      let filtered = childRows;
      const t = termSel.value, y = yearSel.value;
      if(t) filtered = filtered.filter(r=>r.term===t);
      if(y) filtered = filtered.filter(r=>String(r.year)===String(y));
      renderTable(filtered);
      byId('summary').textContent = computeSummary(filtered);
    }

    termSel.onchange = applyFilters;
    yearSel.onchange = applyFilters;

    byId('resultsSection').style.display = 'block';
    applyFilters();
  }catch(ex){
    err.textContent = ex.message;
    err.style.display = 'block';
  }
}

document.getElementById('loginForm').addEventListener('submit', handleLogin);
