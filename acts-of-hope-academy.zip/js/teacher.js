// Teacher CSV -> JSON converter (client-side)
function byId(id){ return document.getElementById(id); }

async function sha256(text){
  const enc = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(hash)).map(b=>b.toString(16).padStart(2,'0')).join('');
}

// very small CSV parser: handles commas and quoted cells
function parseCSV(text){
  const rows = [];
  let cur = '', inQuotes = false, row = [];
  for (let i=0;i<text.length;i++){
    const ch = text[i];
    if (ch === '"' ){
      if (inQuotes && text[i+1] === '"'){ cur+='"'; i++; } else { inQuotes = !inQuotes; }
    } else if (ch === ',' && !inQuotes){
      row.push(cur); cur='';
    } else if ((ch === '\n' || ch === '\r') && !inQuotes){
      if (cur !== '' || row.length>0){ row.push(cur); rows.push(row); row=[]; cur=''; }
    } else {
      cur += ch;
    }
  }
  if (cur !== '' || row.length>0){ row.push(cur); rows.push(row); }
  return rows;
}

function downloadBlob(filename, content, type='application/json'){
  const blob = new Blob([content], {type});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.textContent = 'Download '+filename;
  a.className = 'btn';
  byId('downloads').appendChild(a);
  const br = document.createElement('div'); br.style.height='10px'; byId('downloads').appendChild(br);
}

byId('convertBtn').addEventListener('click', async ()=>{
  byId('downloads').innerHTML = '';
  const file = byId('csvFile').files[0];
  if(!file){ byId('convertMsg').textContent='Choose a CSV file first.'; return; }
  const text = await file.text();
  const rows = parseCSV(text).filter(r=>r.length && r.some(c=>c.trim() !== ''));
  if(rows.length < 2){ byId('convertMsg').textContent='CSV must include a header and at least one row.'; return; }
  const header = rows[0].map(h=>h.trim());
  const required = ['studentId','name','class','parentName','parentPhone','year','term','subject','score','grade','remarks','date(YYYY-MM-DD)','pin'];
  const missing = required.filter(k=>!header.includes(k));
  if(missing.length){ byId('convertMsg').textContent='Missing columns: '+missing.join(', '); return; }
  const H = Object.fromEntries(header.map((h,i)=>[h,i]));

  const studentsMap = new Map();
  const results = [];

  for (let r=1; r<rows.length; r++){
    const row = rows[r];
    if(!row.length) continue;
    const studentId = row[H['studentId']].trim();
    if(!studentId) continue;

    // student object (de-duped)
    if(!studentsMap.has(studentId)){
      const pin = (row[H['pin']]||'').trim();
      const student = {
        studentId,
        name: row[H['name']].trim(),
        class: row[H['class']].trim(),
        parentName: row[H['parentName']].trim(),
        parentPhone: row[H['parentPhone']].trim(),
        pinHash: pin ? await sha256(pin) : ''
      };
      studentsMap.set(studentId, student);
    }else{
      // If PIN provided later, update hash
      const pin = (row[H['pin']]||'').trim();
      if(pin){
        const s = studentsMap.get(studentId);
        s.pinHash = await sha256(pin);
      }
    }

    // results entries
    results.push({
      studentId,
      year: Number(row[H['year']]]),
      term: row[H['term']].trim(),
      subject: row[H['subject']].trim(),
      score: Number(row[H['score']]]),
      grade: row[H['grade']].trim(),
      remarks: row[H['remarks']].trim(),
      date: row[H['date(YYYY-MM-DD)']].trim()
    });
  }

  // Clean students (remove any empty pinHash)
  const students = Array.from(studentsMap.values()).map(s => ({
    ...s,
    pinHash: s.pinHash || ''
  }));

  // Validate: ensure every student has a pinHash
  const noPin = students.filter(s=>!s.pinHash);
  if(noPin.length){
    byId('convertMsg').textContent = 'Warning: Some students have NO PIN set ('+noPin.map(s=>s.studentId).join(', ')+'). Parents for these students will not be able to log in.';
  }else{
    byId('convertMsg').textContent = 'Converted! Now download the JSON files below.';
  }

  downloadBlob('students.json', JSON.stringify(students, null, 2));
  downloadBlob('results.json', JSON.stringify(results, null, 2));
});
